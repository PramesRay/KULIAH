/*
Nama    : Prames Ray Lapian
NPM     : 140810210059
Tanggal : 9 September 2021
Program : Biodata
*/

#include <iostream>

using namespace std;

int main()
{
cout<<"=====================================================================================\n";
cout<<"=====================================================================================\n";
cout<<"HHHHHHHHH     HHHHHHHHH                   lllllll\n";                                   
cout<<"H:::::::H     H:::::::H                   l:::::l\n";                                   
cout<<"H:::::::H     H:::::::H                   l:::::l\n";                                   
cout<<"HH::::::H     H::::::HH                   l:::::l\n";                                   
cout<<"  H:::::H     H:::::H      eeeeeeeeeeee    l::::l    ooooooooooo      ooooooooooo\n";   
cout<<"  H:::::H     H:::::H    ee::::::::::::ee  l::::l  oo:::::::::::oo  oo:::::::::::oo\n"; 
cout<<"  H::::::HHHHH::::::H   e::::::eeeee:::::eel::::l o:::::::::::::::oo:::::::::::::::o\n";
cout<<"  H:::::::::::::::::H  e::::::e     e:::::el::::l o:::::ooooo:::::oo:::::ooooo:::::o\n";
cout<<"  H:::::::::::::::::H  e:::::::eeeee::::::el::::l o::::o     o::::oo::::o     o::::o\n";
cout<<"  H::::::HHHHH::::::H  e:::::::::::::::::e l::::l o::::o     o::::oo::::o     o::::o\n";
cout<<"  H:::::H     H:::::H  e::::::eeeeeeeeeee  l::::l o::::o     o::::oo::::o     o::::o\n";
cout<<"  H:::::H     H:::::H  e:::::::e           l::::l o::::o     o::::oo::::o     o::::o\n";
cout<<"HH::::::H     H::::::HHe::::::::e         l::::::lo:::::ooooo:::::oo:::::ooooo:::::o\n";
cout<<"H:::::::H     H:::::::H e::::::::eeeeeeee l::::::lo:::::::::::::::oo:::::::::::::::o\n";
cout<<"H:::::::H     H:::::::H  ee:::::::::::::e l::::::l oo:::::::::::oo  oo:::::::::::oo\n"; 
cout<<"HHHHHHHHH     HHHHHHHHH    eeeeeeeeeeeeee llllllll   ooooooooooo      ooooooooooo\n";
cout<<"=====================================================================================\n";
cout<<"=====================================================================================\n";
    cout<<"\n";
    cout<<"\n";
    cout<<"\n";
    cout<<"Nama                 : Prames Ray Lapian\n";
    cout<<"NPM                  : 140810210059\n";
    cout<<"Tempat, Tanggal Lahir: Jakarta, 16 Maret 2004\n";
    cout<<"Hobi                 : Main Games (PUBG atau Point Blank) & Motoran\n";
    cout<<"                       Buat akang / teteh / temen temen, KUY KITA MABAR!!!\n";
    cout<<"                       Sok dicari namanya MATISYAHIDKO\n";
    cout<<"                       Mohon maaf sebelumnya tapi saya noob, jadi mohon bimbingannya ya...\n";
    cout<<"Alasan masuk UNPAD   : Diarahkan Tuhan / alias ga masuk dimana-mana\n";
    cout<<"Alasan milih TI      : 1. Ada ketertarikan di bidang IT\n";
    cout<<"                       2. Punya rasa penasaran yang tinggi akan cara kerja suatu hal\n";
    cout<<"                       3. Melihat prospek kerja yang cukup luas\n";
    cout<<"\n";
    cout<<"\n";
    cout<<"\n";
cout<<"=================================================================================================\n";
cout<<"=================================================================================================\n";
cout<<" ######     ###    ##          ###    ##     ##    ##    ## ######## ##    ##    ###    ##\n";       
cout<<"##    ##   ## ##   ##         ## ##   ###   ###    ##   ##  ##       ###   ##   ## ##   ##\n";       
cout<<"##        ##   ##  ##        ##   ##  #### ####    ##  ##   ##       ####  ##  ##   ##  ##\n";       
cout<<" ######  ##     ## ##       ##     ## ## ### ##    #####    ######   ## ## ## ##     ## ##\n";       
cout<<"      ## ######### ##       ######### ##     ##    ##  ##   ##       ##  #### ######### ##\n";       
cout<<"##    ## ##     ## ##       ##     ## ##     ##    ##   ##  ##       ##   ### ##     ## ##\n";       
cout<<" ######  ##     ## ######## ##     ## ##     ##    ##    ## ######## ##    ## ##     ## ########\n";
cout<<"=================================================================================================\n";
cout<<"=================================================================================================\n";
} 