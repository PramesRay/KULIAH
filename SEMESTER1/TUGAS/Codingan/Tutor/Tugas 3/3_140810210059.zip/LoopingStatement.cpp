/*
Nama Program    : Looping Statement
Nama            : Prames Ray Lapian
NPM             : 140810210059
Tanggal Buat    : 26 September 2021
Deskripsi       : Membuat Pola
*/

#include <iostream>
using namespace std;

int main()
{
int i, j, k, a, l;
cout << "Input Lebar Roket: ";
cin >> a;
cout << "=====================\n";
cout << " THIS IS YOUR ROCKET \n";
cout << "=====================\n";
cout << endl;

for (i = 1; i <= a; i++)
{
    for (j = 1; j <= a-i; j++)
    {
        cout<<" ";
    }
    for (k = 1; k <= i+(i-1); k++)
    {
        cout<<"*";
    }
    cout << endl;
}
for (i = 1; i <= 2*a; i++) 
{
    for(j=1; j <= 2*a-1; j++) 
    {
      cout << "*";
    }
    cout << endl;
  }
return 0;
}
