package project.akhir.uas.pbo.kelompok.a;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;                 //
import javafx.scene.Scene;                  //
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.shape.Line;             //
import javafx.scene.shape.Rectangle;        //
import javafx.scene.control.TextField;      //
import javafx.scene.text.Font;              //
import javafx.scene.text.FontWeight;        //
import javafx.stage.Stage;                  //
import javafx.scene.Node;  
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class SinglePlayerController implements Initializable {
    private Stage stage;
    private Parent root;

    @FXML
    private Button button1;             

    @FXML
    private Button button2;

    @FXML
    private Button button3;

    @FXML
    private Button button4;

    @FXML
    private Button button5;

    @FXML
    private Button button6;

    @FXML
    private Button button7;

    @FXML
    private Button button8;

    @FXML
    private Button button9;

    @FXML
    private Label roundText;

    @FXML
    private TextField skorOField;
    @FXML
    private TextField skorXField;

    @FXML
    private Label playerX;
    @FXML
    private Label playerO;

    @FXML
    private Line lineX1;
    @FXML
    private Line lineX2;
    @FXML
    private Line lineX3;
    @FXML
    private Line lineX4;

    @FXML
    private Line lineO1;
    @FXML
    private Line lineO2;
    @FXML
    private Line lineO3;
    @FXML
    private Line lineO4;

    @FXML
    private Rectangle kotakX;
    @FXML
    private Rectangle kotakO;

    @FXML
    private Label winnerX;
    @FXML
    private Label winnerO;
    
    private int playerTurn = 0;
    private int roundCounter = 1;
    private int skorX = 0;
    private int skorO = 0;
    private Boolean muncul = true;

    ArrayList<Button> buttons;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        buttons = new ArrayList<>(Arrays.asList(button1,button2,button3,button4,button5,button6,button7,button8,button9));  // Memasukkan button1 - button9 ke dalam ArrayList

        roundText.setText("ROUND " + String.valueOf(roundCounter));
        fontBold(playerX);
        fontRegular(playerO);
        buttons.forEach(button ->{                                                                                          // Untuk menerapkan apa yang ada didalam scope terhadap seluruh button dengan looping
            setupButton(button);                                                                                            // Untuk set kondisi ketika button ditekan
            button.setFocusTraversable(false);                                                                              // Untuk set Button agar tidak terseleksi sehingga menghasilkan border biru
        });
    }
    
    @FXML
    void restartGame(ActionEvent event) {                                                                                   // Event ketika button reset ditekan
        buttons.forEach(this::resetButton);                                                                                 // Untuk set setiap button dengan memanggil fungsi resetButton dan menerapkan di semua button dengan looping
    }
    
    public void resetButton(Button button){                                                                                       
        button.setDisable(false);                                                                                           // Untuk set button agar bisa ditekan kembali
        button.setText("");  
        muncul = false;
        winnerXFrame(muncul);
        winnerOFrame(muncul);                                                                                            // Untuk mengembalikan text di button menjadi null
        roundText.setText("ROUND " + String.valueOf(roundCounter));
    }

    private void setupButton(Button button) {
        button.setOnMouseClicked(mouseEvent -> {                                                                            // Kondisi ketika button di tekan
            setPlayerSymbol(button);                                                                                        // Untuk cek giliran dan set text nya sesuai gilirannya
            button.setDisable(true);                                                                                        // Untuk set button agar tidak bisa ditekan lagi
            checkIfGameIsOver();                                                                                            // Untuk cek apakah sudah ada pemenang atau belum
        });
    }

    public void setPlayerSymbol(Button button){
        if(playerTurn % 2 == 0){                                                                                            // Conditional statement untuk player 1
            button.setText("X");
            playerTurn = 1;
            fontBold(playerO);
            fontRegular(playerX);
        } else{                                                                                                             // Conditional statement untuk player 2
            button.setText("O");
            playerTurn = 0;
            fontBold(playerX);
            fontRegular(playerO);
        }
    }

    public void fontBold(Label player){
        player.setFont(Font.font("SansSerif", FontWeight.BOLD, 30));
    }

    public void fontRegular(Label player){
        player.setFont(Font.font("SansSerif", 25));
        playerO.setStyle("-fx-font-weight: regular;");
    }

    public void winnerXFrame(Boolean muncul){
        if(muncul == true){
            lineX1.setVisible(true);
            lineX2.setVisible(true);
            lineX3.setVisible(true);
            lineX4.setVisible(true);
            kotakX.setVisible(true);
            winnerX.setVisible(true);
        }
        else {
            lineX1.setVisible(false);
            lineX2.setVisible(false);
            lineX3.setVisible(false);
            lineX4.setVisible(false);
            kotakX.setVisible(false);
            winnerX.setVisible(false);
        }
    }

    public void winnerOFrame(Boolean muncul){
        if(muncul == true){
            lineO1.setVisible(true);
            lineO2.setVisible(true);
            lineO3.setVisible(true);
            lineO4.setVisible(true);
            kotakO.setVisible(true);
            winnerO.setVisible(true);
        }
        else {
            lineO1.setVisible(false);
            lineO2.setVisible(false);
            lineO3.setVisible(false);
            lineO4.setVisible(false);
            kotakO.setVisible(false);
            winnerO.setVisible(false);
        }
    }

    public void checkIfGameIsOver(){
        for (int a = 0; a < 8; a++) {
            String line = switch (a) {                                                                                      // Mencari setiapi kasus yang memenuhi syarat untuk menang dengan menggabungkan isi teks  dari setiap button
                case 0 -> button1.getText() + button2.getText() + button3.getText();                                        // Horizontal
                case 1 -> button4.getText() + button5.getText() + button6.getText();                                        // Horizontal
                case 2 -> button7.getText() + button8.getText() + button9.getText();                                        // Horizontal

                case 3 -> button1.getText() + button5.getText() + button9.getText();                                        // Diagonal
                case 4 -> button3.getText() + button5.getText() + button7.getText();                                        // Diagonal

                case 5 -> button1.getText() + button4.getText() + button7.getText();                                        // Vertikal
                case 6 -> button2.getText() + button5.getText() + button8.getText();                                        // Vertikal
                case 7 -> button3.getText() + button6.getText() + button9.getText();                                        // Vertikal
                default -> null;
            };
            
            //X winner
            if (line.equals("XXX")) {                                                                                       // Jika penggabungan teks button di atas menghasilkan "XXX"
                muncul = true;
                winnerXFrame(muncul);   
                roundCounter++;  
                skorX++;
                skorXField.setText(String.valueOf(skorX));   
            }
            
            //O winner
            else if (line.equals("OOO")){                                                                                   // Jika penggabungan teks button di atas menghasilkan "OOO"                                                                               
                muncul = true;
                winnerOFrame(muncul);  
                roundCounter++;                                                                             // maka, akan di set teks Judul menjadi "O win!"
                skorO++;
                skorOField.setText(String.valueOf(skorO));
            }

            //DRAW
            else {
                String temp = "";
                for (Button button : buttons) {
                    temp = temp + button.getText();                                                                         // Setiap button di click, maka pangjang String temp akan bertambah 1
                }
                if (temp.length() == 9) {                                                                                   // Jika seluruh button sudah di click
                    roundText.setText("DRAW!");   
                    roundCounter++;                                                                         // maka, akan di set teks Judul menjadi "DRAW!"
                }
            }
        }
    }

    public void openHome(ActionEvent event) throws IOException{
        root = FXMLLoader.load(getClass().getResource("/fxml/Home.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));                                  
        stage.show(); 
    }
}
