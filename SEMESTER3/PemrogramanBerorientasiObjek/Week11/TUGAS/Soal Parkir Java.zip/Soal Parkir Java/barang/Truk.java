package barang;

public class Truk extends Kendaraan {
    Truk(){
        super();
    }
    // fungsionalitas
    public int biayaParkir(){
        return 5000;
    }
}
