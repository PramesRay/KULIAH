package barang;

public class Motor extends Kendaraan {
    Motor(){
        super();
    }
    // fungsionalitas
    public int biayaParkir(){
        return 2000;
    }
}
