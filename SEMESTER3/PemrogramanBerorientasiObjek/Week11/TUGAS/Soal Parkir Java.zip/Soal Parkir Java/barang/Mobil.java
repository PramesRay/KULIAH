package barang;

public class Mobil extends Kendaraan{
    Mobil(){
        super();
    }
    // fungsionalitas
    public int biayaParkir(){
        return 3000;
    }
}
