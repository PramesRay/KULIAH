package barang;

public class Orang {
    private String nama;
    Orang(){
        this.nama = "";
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    public String getNama() {
        return nama;
    }
}