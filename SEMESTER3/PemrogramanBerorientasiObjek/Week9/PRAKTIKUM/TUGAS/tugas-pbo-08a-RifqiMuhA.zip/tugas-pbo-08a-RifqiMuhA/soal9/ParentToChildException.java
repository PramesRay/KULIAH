public class ParentToChildException extends Exception{
    /*
     * @param
     *  String that will displayed as message
     */
    public ParentToChildException(String msg){
        super(msg);
    }
}
